package com.example.jose_cavero_semana6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Lista : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista)
    }
}